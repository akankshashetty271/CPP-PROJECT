// ConsoleApplication59.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<iostream>
#include<string>
#include<vector>
#include<Windows.h>
#include<iomanip>
#include<fstream>
using namespace std;
struct Member
{
	int age;
	string name;
	string bloodg;
	unsigned long int phnno;
}
MemberObject;

vector<Member>VectorObject;

class DonationR
{
	public:
	void Registration();
	void DatainFile();
	//void validate();
	void display();
	//void choice();
};
void DonationR::Registration()
{
	
	cin.ignore();
	cout << "ENTER AGE:";
	cin >> MemberObject.age;
	cout << "ENTER NAME";
	cin.ignore();
	getline(cin, MemberObject.name);
	
	cout << "ENTER BLOODGROUP";
	cin >> MemberObject.bloodg;
	cout << "ENTER PHONE_NO";
	cin >> MemberObject.phnno;
	
}

void DonationR::DatainFile()
{
	ofstream  fobj;
	fobj.open("record.txt");
	for (int i = 0; i<signed(VectorObject.size()); i++)
	{
		//if()
		fobj << VectorObject[i].name << "\n" << VectorObject[i].age << "\n" << VectorObject[i].bloodg << "\n" << VectorObject[i].phnno;	

	}
	
	fobj.close();


}
void DonationR::display()
{
	ifstream iobj;
	iobj.open("record.txt");
	for (int i = 0; i<signed(VectorObject.size()); i++)
	{
		cout << "------------------------------------------DATA RECORDED-----------------------------------------------------------" << endl;
		iobj >> VectorObject[i].name>> VectorObject[i].age>> VectorObject[i].bloodg>> VectorObject[i].phnno;
		cout<<"NAME:" << VectorObject[i].name <<"\n"<<"AGE:"<< VectorObject[i].age<< "\n" <<"BLOOD-GROUP:" << VectorObject[i].bloodg<<"\n"<<"PHONE-NO:" << VectorObject[i].phnno<<"\n";
		cout << "-----------------------------------------------------------------------------------------------------------------------" << endl;
	}
}
class Choice
{
	public:
		void  choice();
		void organ();
		void tissues();

};
void Choice::choice()
{
	int op;
	for (int i = 0; i<signed(VectorObject.size()); i++)
	{
		
		cout << VectorObject[i].name << " enter your choice";
		cout << endl << "After my death I would like to donate" << endl;
		cout << "1)Any Part of My Body" << endl << "2)ORGANS" << endl << "3)TISSUES" << endl;
	
		cin >> op;


		system("CLS");

		switch (op)
		{
		case 1:
			cout << "****************************************************Thank You*********************************************************" << endl;
			break;
		case 2:
			organ();
			break;
		case 3:
			tissues();
			break;
		default:
			cout << "Please choose valid option";
			break;


		}
	}
	
}
void Choice::organ()
{
	int no;
	
	cout << endl << "1.KIDNEYS" << endl << "2.HEART" << endl << "3.LIVER" << endl << "4.Pancreas" << endl;
	cout << endl << "Enter option number:";
	cin >> no;


	system("CLS");

	if (no == 1)
	{
		cout << endl << "The organ you would like to donate is Kidneys" << endl;
	}
	else if (no == 2)
	{
		cout << endl << "The organ you would like to donate is Heart" << endl;
	}
	else if (no == 3)
	{
		cout << endl << "The organ you would like to donate is liver" << endl;
	}
	else if (no == 4)
	{
		cout << endl << "The organ you would like to donate is Pancrease" << endl;
	}
	else
	{
		cout << endl << "NO VALID INPUT" << endl;
		Sleep(3000);
		exit(1);
	}


	
}
void Choice::tissues()
{

	int no;
	cout << endl << "1.CORNEA" << endl << "2.HEAST VALVE" << endl << "3.BONE MARROW" << endl << "4.SKIN" << endl;
	cout << endl << "Enter option number:";
	cin >> no;

	system("CLS");

	if (no == 1)
	{
		cout << endl << "The organ you would like to donate is CORNEA" << endl;
	}
	else if (no == 2)
	{
		cout << endl << "The organ you would like to donate is HEAST VALVE" << endl;
	}
	else if (no == 3)
	{
		cout << endl << "The organ you would like to donate is BONE MARROW" << endl;
	}
	else if (no == 4)
	{
		cout << endl << "The organ you would like to donate is SKIN" << endl;
	}
	else
	{
		cout << endl << "NO VALID INPUT" << endl;
		Sleep(3000);
		exit(1);
	}

	
}

class Registration
{
	public:
	void registration();
};

void Registration::registration()
{
	cout << endl << setw(70) << "Certificate of Regitration" << endl;
	
	for (int i = 0; i<signed(VectorObject.size()); i++)
	{
		cout << "Certificate number:" << i+1<<endl;
		cout << "This is to certify Ms./Mr " << VectorObject[i].name << " age " << VectorObject[i].age << " for donation in organ and tissuse transpalnt organization." << endl;
		cout << "Place:Pune" << setw(20) << "Date:3/6/22 ";
		cout << endl;
	}
}
int main()
{
	int i = 0;
	
	cout << setw(70) << "ORGAN AND TISSUE TRANSPALNT ORGANIZATION" << endl;
	cout << setw(60) << "Registration Form" << endl;
	cout << endl << "PERSONAL-DEMOGRAPHIC DATA" << endl;
	int Count = 0;
	
	DonationR Dobject;
	Choice  Cobject;
	Registration Robject;
	
	cout << sizeof(Dobject)<<"\n";
	cout << "ENTER THE MEMBERS IN FAMILY:";
	cin >> Count;

	system("CLS");

	
	for(int i=1;i<=Count;i++)
	{
		
		
		cout << "Record:" << i << endl;
		Dobject.Registration();

		unsigned long int ph = MemberObject.phnno;
		string str = to_string(ph);
		int  m = str.length();
		if (MemberObject.age > 18) 
		{
			if (m == 10)
			{
				VectorObject.push_back(MemberObject);
			}
			else
			{
				i--;
				cout << "Invalid  phone enter again" << endl;
			}
		}
		else
		{
			i--;
			cout << "Invalid  age enter again" << endl;
			
		}
		
	}

	system("CLS");
	
	Dobject.DatainFile();
	
	Dobject.display();
	
	Cobject.choice();
	
	Sleep(3000);
	
	system("CLS");
	
	Robject.registration();
	
	system("pause");
		
		return 0;
}

